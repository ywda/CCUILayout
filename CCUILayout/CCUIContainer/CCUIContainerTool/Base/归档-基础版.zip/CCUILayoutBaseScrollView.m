//
//  CCUILayoutBaseScrollView.m
//  CCUILayout
//
//  Created by Admin on 2020/10/17.
//  Copyright © 2020 Admin. All rights reserved.
//

#import "CCUILayoutBaseScrollView.h"
#import "CCUILayoutBaseLogic.h"

@interface CCUILayoutBaseScrollView ()<UIScrollViewDelegate>

@property(nonatomic,strong)CCUILayoutBaseMode *base;

@end

@implementation CCUILayoutBaseScrollView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self setUpDataAndUi];
    }
    return self;
}

- (void) setUpDataAndUi
{
    self.base = [CCUILayoutBaseMode new];
    [self setUpdateScrollView];
    [self.base addObserver:self
                forKeyPath:@"showDebugTag"
                   options:NSKeyValueObservingOptionNew
                   context:NULL];
}

- (void) setUpdateScrollView {
    [self addSubview:self.scrollView];
}

- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.frame];
        _scrollView.delegate = self;
        _scrollView.scrollEnabled = YES;
        _scrollView.bounces = YES;
        _scrollView.userInteractionEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.layer.masksToBounds = YES;
        _scrollView.decelerationRate = UIScrollViewDecelerationRateNormal;
        
    }
    return _scrollView;
}

- (void) configUIControls:(NSArray<UIResponder *> *)subUis
                   layout:(NSArray<CCUILayoutUiMode*> *)subLModes
             mainTabEdges:(UIEdgeInsets)edges
{
    [self update_TabEdges:edges];
    
    CCUILayoutBaseLogic *checkLg = [CCUILayoutBaseLogic checkPropertyWithUIControls:subUis
                                                                                layout:subLModes];
    self.base.dbMode = [NSMutableArray arrayWithArray:checkLg.uims];
    
    [self setUpUI];
}

- (void)update_TabEdges:(UIEdgeInsets)edges
{
    self.base.edges = edges;
    [self layoutSubviews];
}

- (void)layoutSubviews
{
    CGFloat top = self.base.edges.top;
    CGFloat left = self.base.edges.left;
    CGFloat bottom = self.base.edges.bottom;
    CGFloat right = self.base.edges.right;
    
    [self.scrollView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(top);
        make.left.mas_equalTo(left);
        make.bottom.mas_equalTo(bottom);
        make.right.mas_equalTo(right);
    }];
    
    [[self class] cancelPreviousPerformRequestsWithTarget:self
                                                 selector:@selector(performWhenLayoutSubviews)
                                                   object:nil];
    
    [self performSelector:@selector(performWhenLayoutSubviews)
               withObject:nil
               afterDelay:0.0125];
}

- (void) performWhenLayoutSubviews {
    
    [self.base update_SubViewsForScrollView:self.scrollView];
    [self.base layout_SubViewsForScrollView:self.scrollView];
}

- (void) configUIControlsIsLoadDebug:(BOOL)isDebug
                        mainTabEdges:(UIEdgeInsets)edges
                          adapterApp:(BOOL)isAdapter{
    [self update_TabEdges:edges];
    
    Class c = [self class];
    NSString *cName = NSStringFromClass(c);
    
    if (isAdapter) {
        cName = [CCUILayoutConfig getConfigPlistNameBy:cName];
    }
    
    NSString *fileName = isDebug ? [cName stringByAppendingFormat:@"_debug"] : cName;
    
    [self configUIControlsWithFilename:fileName];
}

- (void) configUIControlsWithFilename:(NSString*)plist
{
    
    if (![plist containsString:@".plist"]) {
        if (plist.length > 0 ) {
            plist = [plist stringByAppendingString:@".plist"];
        }else{
            return;
        }
    }
    
    NSMutableArray *queryData = [CCUILayoutUiMode mj_objectArrayWithFilename:plist];
    self.base.dbMode = [NSMutableArray arrayWithArray:queryData];
    
    if (!self.base.uisubviewsRb) {
        __weak typeof(self) ws = self;
        self.base.uisubviewsRb = ^(NSArray<UIResponder *> *uis, NSMutableArray<CCUILayoutUiMode *> *uims) {
            ws.cc_subviews = [NSArray arrayWithArray:uis];
            ws.cc_subviewModes = [NSMutableArray arrayWithArray:uims];;
        };
    }
    [self setUpUI];
}

- (void) setUpUI
{
    
    dispatch_async(dispatch_get_main_queue(), ^{

        [self.base create_SubViewsForScrollView:self.scrollView];
        [self.base update_SubViewsForScrollView:self.scrollView];
        [self.base layout_SubViewsForScrollView:self.scrollView];
        
        [self layoutSubviews];
    });
}

- (void) wholeUIControls:(void(^)(NSArray<UIResponder*>*,NSMutableArray<CCUILayoutUiMode*>*))subviews
{
    self.base.uisubviewsRb = ^(NSArray<UIResponder *> *uis, NSMutableArray<CCUILayoutUiMode *> *uims) {
        !subviews ? : subviews(uis,uims);
    };
}

- (void) getUIControlsTouchIndex:(void(^)(UIResponder *ui,CCUILayoutUiMode *uim,NSInteger index))reback
{
    self.base.clickElementRb = ^(UIResponder *ui, CCUILayoutUiMode *uim, NSInteger index) {
        !reback ? : reback(ui,uim,index);
    };
}

- (void) updateUIControls:(NSMutableArray<CCUILayoutUiMode*> *)cc_subviewModes
                animation:(BOOL)isOpen{
    self.base.dbMode = [NSMutableArray arrayWithArray:cc_subviewModes];
    if (isOpen) {
        [CCSpeedyTool cc_setInSlideAanimation:self.scrollView delay:0.25];
    }
    [self layoutSubviews];
}

- (void) updateUIControl:(CCUILayoutUiMode*)cc_uimode animation:(BOOL)isOpen {
     for (int i = 0; i < self.base.dbMode.count; i++) {
         
         CCUILayoutUiMode *one = self.base.dbMode[i];
         
         if (one.bind == cc_uimode.bind &&
             [one.name isEqualToString:cc_uimode.name]) {
             
             [self.base.dbMode replaceObjectAtIndex:i withObject:cc_uimode];
             [self updateUIControls:self.base.dbMode animation:isOpen];
             
             break;
         }
     }
}

- (void) setDebugShowSection:(BOOL)isOpen
{
    self.base.showDebugTag = isOpen;
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary<NSKeyValueChangeKey,id> *)change
                       context:(void *)context
{
    NSLog(@"\n %s —— %@ ",__func__,change);
    
    if ([keyPath isEqualToString:@"showDebugTag"]) {
        
        if ([change[@"new"] intValue] == 1) {
            
            if (self.base.dbMode.count > 0) {
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [self.base update_SubViewsForScrollView:self.scrollView];
                    [self.base layout_SubViewsForScrollView:self.scrollView];
                    
                    [self layoutSubviews];
                });
            }
        }
    }
}

- (CCUILayoutUiMode* _Nullable) getClmFrom:(NSInteger) bindNum {
    
    if (self.cc_subviewModes.count) {
        
        for (NSInteger i = 0; i < self.cc_subviewModes.count; i++) {
            CCUILayoutUiMode *object = self.cc_subviewModes[i];
            
            if (object.bind.integerValue == bindNum) {
                
                return object;
                break;
            }
        }
    }
    return Nil;
}

@end
